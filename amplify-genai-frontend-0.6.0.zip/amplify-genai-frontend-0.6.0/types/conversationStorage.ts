export interface ConversationStorage {
    storageLocation: 'local-only' | 'cloud-only' | 'future-local' | 'future-cloud';
  }
  
  


export interface Features {
    [key: string]: boolean;
}
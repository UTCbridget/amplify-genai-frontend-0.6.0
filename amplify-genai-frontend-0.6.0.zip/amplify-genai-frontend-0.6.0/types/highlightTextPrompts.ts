export type highlightSource = 'chat' | 'artifact';

export enum HighlightPromptTypes {
  FAST_EDIT = 'Fast Edit',
  PROMPT = 'Prompt',
  COMPOSITE = 'Composite'
}



export enum ReservedTags {
    ASSISTANT_BUILDER = "amplify:assistant-builder",
    ASSISTANT_API_KEY_MANAGER = "amplify:api-key-manager",
    ASSISTANT_API_HELPER = "amplify:api-doc-helper",
    SYSTEM = "amplify:system",
    ASSISTANT = "amplify:assistant"
}